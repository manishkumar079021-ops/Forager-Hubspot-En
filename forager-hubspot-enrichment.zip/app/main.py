"""FastAPI webhook server for HubSpot -> Forager enrichment.

Endpoints:
  GET  /health
  POST /webhooks/hubspot/company   (HubSpot "company created" webhook)
  POST /webhooks/hubspot/contact   (HubSpot "contact created" webhook)
"""
import asyncio
import logging
import uuid

from fastapi import BackgroundTasks, FastAPI, Query, Request
from fastapi.responses import JSONResponse

from .config import get_settings
from .enricher import Enricher

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
log = logging.getLogger("app")

app = FastAPI(title="Forager x HubSpot Enrichment", version="1.0.0")
settings = get_settings()


def _check_secret(secret: str | None) -> bool:
    return not settings.webhook_secret or secret == settings.webhook_secret


def _extract_object_id(body) -> str | None:
    """HubSpot webhook payloads are a list like [{"objectId": 123, ...}] or a dict."""
    if isinstance(body, list) and body:
        return str(body[0].get("objectId"))
    if isinstance(body, dict):
        return str(body.get("objectId") or body.get("id"))
    return None


async def _run_company_flow(company_id: str) -> None:
    enricher = Enricher(get_settings())
    try:
        res = await enricher.enrich_company_by_id(company_id)
        for n in res.notes:
            log.info("[company %s] %s", company_id, n)
        company = await enricher.hubspot.get_company(company_id)
        domain = (company or {}).get("properties", {}).get("domain")
        if domain and res.ok:
            # enrich existing contacts
            for contact in await enricher.hubspot.contacts_for_company(company_id):
                r = await enricher.enrich_contact_by_id(contact["id"])
                for n in r.notes:
                    log.info("[existing contact %s] %s", contact["id"], n)
            # discover new contacts (job-title filtered)
            r = await enricher.find_and_create_contacts(company_id, domain)
            for n in r.notes:
                log.info("[new contacts] %s", n)
    except Exception:
        log.exception("company flow failed for %s", company_id)
    finally:
        await enricher.aclose()


async def _run_contact_flow(contact_id: str) -> None:
    enricher = Enricher(get_settings())
    try:
        res = await enricher.enrich_contact_by_id(contact_id)
        for n in res.notes:
            log.info("[contact %s] %s", contact_id, n)
    except Exception:
        log.exception("contact flow failed for %s", contact_id)
    finally:
        await enricher.aclose()


@app.get("/health")
async def health():
    return {"status": "ok", "service": "forager-hubspot-enrichment"}


@app.post("/webhooks/hubspot/company")
async def company_webhook(request: Request, background: BackgroundTasks,
                          secret: str | None = Query(default=None)):
    if not _check_secret(secret):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    body = await request.json()
    company_id = _extract_object_id(body)
    if not company_id:
        return JSONResponse({"error": "no objectId in payload", "got": body}, status_code=400)
    background.add_task(_run_company_flow, company_id)
    return {"received": True, "company_id": company_id, "job_id": str(uuid.uuid4())}


@app.post("/webhooks/hubspot/contact")
async def contact_webhook(request: Request, background: BackgroundTasks,
                          secret: str | None = Query(default=None)):
    if not _check_secret(secret):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    body = await request.json()
    contact_id = _extract_object_id(body)
    if not contact_id:
        return JSONResponse({"error": "no objectId in payload", "got": body}, status_code=400)
    background.add_task(_run_contact_flow, contact_id)
    return {"received": True, "contact_id": contact_id, "job_id": str(uuid.uuid4())}
