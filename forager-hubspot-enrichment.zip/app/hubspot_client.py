"""Defensive HubSpot CRM (v3) client with rate-limit aware retries."""
import logging

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from .config import Settings

log = logging.getLogger("hubspot")
BASE = "https://api.hubapi.com"

COMPANY_PROPS = "domain,name,website,description,industry,annualrevenue,numberofemployees,linkedin_company_page"
CONTACT_PROPS = "firstname,lastname,email,phone,jobtitle,company,linkedin_url,city,state,country,associatedcompanyid"


class HubSpotClient:
    def __init__(self, settings: Settings):
        self._client = httpx.AsyncClient(
            base_url=BASE,
            headers={"Authorization": f"Bearer {settings.hubspot_access_token}"},
            timeout=httpx.Timeout(30.0),
        )

    async def aclose(self):
        await self._client.aclose()

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=2, min=1, max=30),
        retry=retry_if_exception_type((httpx.TransportError,)),
        reraise=False,
    )
    async def _request(self, method: str, path: str, **kwargs) -> dict | None:
        resp = await self._client.request(method, path, **kwargs)
        if resp.status_code == 429:
            wait_s = float(resp.headers.get("Retry-After", "5"))
            log.warning("HubSpot rate limited, sleeping %ss", wait_s)
            await __import__("asyncio").sleep(wait_s)
            raise httpx.TransportError("rate limited")  # triggers retry
        if resp.status_code in (401, 403, 404):
            log.warning("HubSpot %s %s -> %s: %s", method, path, resp.status_code, resp.text[:300])
            return None
        resp.raise_for_status()
        return resp.json() if resp.content else {}

    # -------------------------------------------------------------- company
    async def get_company(self, company_id: str) -> dict | None:
        return await self._request(
            "GET", f"/crm/v3/objects/companies/{company_id}",
            params={"properties": COMPANY_PROPS},
        )

    async def update_company(self, company_id: str, properties: dict) -> bool:
        result = await self._request(
            "PATCH", f"/crm/v3/objects/companies/{company_id}", json={"properties": properties}
        )
        return result is not None

    # -------------------------------------------------------------- contacts
    async def get_contact(self, contact_id: str) -> dict | None:
        return await self._request(
            "GET", f"/crm/v3/objects/contacts/{contact_id}",
            params={"properties": CONTACT_PROPS},
        )

    async def update_contact(self, contact_id: str, properties: dict) -> bool:
        result = await self._request(
            "PATCH", f"/crm/v3/objects/contacts/{contact_id}", json={"properties": properties}
        )
        return result is not None

    async def create_contact(self, properties: dict, company_id: str | None = None) -> str | None:
        body: dict = {"properties": properties}
        if company_id:
            body["associations"] = [
                {
                    "to": {"id": company_id},
                    "types": [
                        {
                            "associationCategory": "HUBSPOT_DEFINED",
                            "associationTypeId": 1,  # contact -> company
                        }
                    ],
                }
            ]
        result = await self._request("POST", "/crm/v3/objects/contacts", json=body)
        return str(result["id"]) if result else None

    async def _create_company(self, properties: dict) -> str | None:
        result = await self._request("POST", "/crm/v3/objects/companies", json={"properties": properties})
        return str(result["id"]) if result else None

    async def contacts_for_company(self, company_id: str) -> list[dict]:
        assoc = await self._request(
            "GET", f"/crm/v3/objects/companies/{company_id}/associations/contacts"
        )
        ids = [r["id"] for r in (assoc or {}).get("results", [])]
        contacts = []
        for cid in ids:
            contact = await self.get_contact(cid)
            if contact:
                contacts.append(contact)
        return contacts

    async def find_contact_by_property(self, prop: str, value: str) -> dict | None:
        """Deduplication check before creating a new contact."""
        payload = {
            "filterGroups": [{"filters": [{"propertyName": prop, "operator": "EQ", "value": value}]}],
            "properties": ["email", "linkedin_url"],
            "limit": 1,
        }
        result = await self._request("POST", "/crm/v3/objects/contacts/search", json=payload)
        results = (result or {}).get("results", [])
        return results[0] if results else None
